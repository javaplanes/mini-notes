import java.util.Scanner;
import java.io.PrintWriter;
import java.io.FileNotFoundException;
import java.util.concurrent.ThreadLocalRandom;

class Main {
  public static void main(String[] args) {
   
   System.out.println("Java Planes Inc. Mini-Notes Version 1.0");
   
    try{ 
     Thread.sleep(1000);
   }
   catch(Exception e) {
       e.printStackTrace();
   }
   
    Scanner D1 = new Scanner(System.in);
     System.out.println("Hello. What should I call you?");
     String user =  D1.nextLine();
     System.out.println("Hello, " + user + ".");
   
   try{ 
     Thread.sleep(3000);
   }
   catch(Exception e) {
       e.printStackTrace();
   }
 
  System.out.println("Ok! Welcome, " + user + "!");
      
       try{ 
     Thread.sleep(500);
   }
   catch(Exception e) {
       e.printStackTrace();
   }
   
    int numbergen  = ThreadLocalRandom.current().nextInt();

    Scanner yorn = new Scanner (System.in);
    System.out.println("Would you like to write a mini note here to save? (Maximum: 4 Lines.) [Y/N]");
    String yornswer = yorn.nextLine();
   if(yornswer.equals("Y")){
   System.out.println("Ok. Making notepad...");
    
    try{ 
     Thread.sleep(500);
   }
   catch(Exception e) {
       e.printStackTrace();
   }
    
     Scanner L1 = new Scanner(System.in);
     System.out.println("");
     String line1 =  L1.nextLine();
     Scanner L2 = new Scanner(System.in);
     System.out.println("");
     String line2 =  L2.nextLine();
     Scanner L3 = new Scanner(System.in);
     System.out.println("");
     String line3 =  L3.nextLine();
     Scanner L4 = new Scanner(System.in);
     System.out.println("");
     String line4 =  L4.nextLine();
     
     try {
      PrintWriter output= new PrintWriter(numbergen + ".txt");
      output.println("Written by: " + user + ".");
      output.println("");
      output.println(line1);
      output.println(line2);
      output.println(line3);
      output.println(line4);
      output.println("");
      output.println("The code for this mini-note is: " + numbergen + "!");
      output.close();
    }
    catch (FileNotFoundException e){
      e.printStackTrace();
     }    

     System.out.println("Your code for your mini-note is: " + numbergen + "!");

   if (yornswer.equals("")){
   
   }
  }
    }   
   }